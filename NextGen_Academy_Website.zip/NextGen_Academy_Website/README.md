# NextGen Academy Website

A responsive bilingual (Bangla/English) static website for NextGen Academy.

## Included
- Responsive premium-style landing page
- Bangla / English language switch
- Programs for primary, secondary and higher-secondary levels
- Science, Humanities and Business Studies groups
- Default subject lists
- Add-subject modal; changes are saved in the current browser using Local Storage
- Click-to-call and WhatsApp contact links

## Publish with GitHub Pages
1. Create a GitHub repository, for example `nextgen-academy`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub to publish the site. The address will look like `https://YOUR-USERNAME.github.io/nextgen-academy/`.

## Important notes
- This is a front-end static site. Subject additions are saved only in the browser/device where they are made; they do not sync across visitors or devices.
- A secure shared admin panel, online admission form with database, student login, payments, or a live notice-management system needs a backend/database or a suitable third-party service.
- Verify the subject list against the current NCTB curriculum before publishing. You can add, remove or rename subjects in the `defaults` array in `index.html`.
- The current contact links use the phone numbers supplied. Add your centre's address, logo, real class schedule and social links before public launch.
